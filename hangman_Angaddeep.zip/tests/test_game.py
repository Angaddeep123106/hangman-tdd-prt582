
import unittest
from hangman.game import GameState

class TestGameState(unittest.TestCase):
    def test_masking_and_guess(self):
        state = GameState(enteredletter="Apple", lives=3)
        self.assertEqual(state.masked(), "_ _ _ _ _")
        self.assertFalse(state.is_won())
        self.assertFalse(state.is_lost())

        # Write guess in multiple positions
        self.assertTrue(state.guess("p"))
        self.assertEqual(state.masked(), "_ p p _ _")
        self.assertEqual(state.lives, 3)

        # Wrong guess.
        self.assertFalse(state.guess("z"))
        self.assertIn("z", state.missedguess)
        self.assertEqual(state.lives, 2)

        # checking whether repeated wrong guesses doesn't cost lives
        self.assertFalse(state.guess("z"))
        self.assertEqual(state.lives, 2)

        # accepting case sensitive guesses.
        self.assertTrue(state.guess("A"))
        self.assertEqual(state.masked(), "A p p _ _")

        # finishing up a word.
        for ch in "le":
            state.guess(ch)
        self.assertTrue(state.is_won())
        self.assertFalse(state.is_lost())

    def test_non_alpha_rejected(self):
        state = GameState(enteredletter="abc", lives=2)
        with self.assertRaises(ValueError):
            state.guess("1")
        with self.assertRaises(ValueError):
            state.guess("ab")
        with self.assertRaises(ValueError):
            state.guess(" ")

    def test_loss_condition(self):
        state = GameState(enteredletter="a", lives=1)
        self.assertFalse(state.guess("b"))
        self.assertTrue(state.is_lost())

if __name__ == "__main__":
    unittest.main()
