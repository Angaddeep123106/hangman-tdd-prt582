
import random
from typing import List

BASIC_WORDS: List[str] = [
    "hangman", "python", "program", "computer", "science",
    "library", "mouse", "cup", "monitor", "tea", "internet", "algorithm",
    "variables", "water", "functions", "rice", "testing", "fixture", "coding",
]

INTERMEDIATE_PHRASES: List[str] = [
    "hello world", "simple program", "test driven development", "good game", "playing game",
    "hot water", "green tea",
    "fast programming", "study hard", "gaming capabilities"
]

def validate_word(word: str) -> bool:
    #validates wether the selected string is word or phrase. 
    
    word = word.lower().strip()
    if " " in word:
        return word in INTERMEDIATE_PHRASES
    else:
        return word in BASIC_WORDS

def random_basic() -> str:
    return random.choice(BASIC_WORDS)

def random_intermediate() -> str:
    return random.choice(INTERMEDIATE_PHRASES)
