
import sys
import threading
import time
from typing import Optional
from .game import GameState
from . import words
# Function to get input from user with timeout prompts.
def input_with_timeout(prompt: str, timeout: int) -> Optional[str]:
    
    result = {"value": None}
    def reader():
        try:
            result["value"] = input(prompt)
        except EOFError:
            result["value"] = None

    t = threading.Thread(target=reader, daemon=True)
    t.start()
    start = time.time()
    last_shown = None
    try:
        while t.is_alive():
            elapsed = int(time.time() - start)
            remaining = max(0, timeout - elapsed)
            # Prints the remaining time.
            if remaining != last_shown:
                print(f"Time left: {remaining:2d} seconds") 
                last_shown = remaining
            t.join(timeout=1)
            if elapsed >= timeout:
                break
    except KeyboardInterrupt:
        # Triggers interupt if no input.
        raise
    # Treats as no input if timedout.
    if t.is_alive():
        return None
    return result["value"]

def play_round(level: str = "basic", lives: int = 6) -> bool:
    """Play a single round. Returns True if the player won the round, False otherwise."""
    if level not in ("basic", "intermediate"):
        raise ValueError("level must be 'basic' or 'intermediate'")
    enteredletter = words.random_basic() if level == "basic" else words.random_intermediate()
    state = GameState(enteredletter=enteredletter, lives=lives)

    print(f"New Round! Level: {level.title()}")
    while not state.is_won() and not state.is_lost():
        print(f"Word: {state.masked()}   missedguess: {sorted(state.missedguess)}   Lives: {state.lives}")
        guess = input_with_timeout("Enter a letter: ", timeout=15)
        if guess is None or guess.strip() == "":
            # a life is lost if timedout or blank input.
            state.lives -= 1
            print("Time up! You lost a life.")
            continue
        try:
            ok = state.guess(guess[0])
            if ok:
                print("Right Guess!")
            else:
                print("Wrong Guess")
        except ValueError as e:
            print(f"Input error: {e}")

    if state.is_won():
        print(f"You won! The enteredletter was: '{state.enteredletter}'")
        return True
    else:
        print(f"You lost. The enteredletter was: '{state.enteredletter}'")
        return False

def main():
    print("**** Hangman (TDD Edition) ****")
    score = 0
    rounds = 0
    while True:
        # Ask level
        lvl = ""
        while lvl not in ("1", "2", "q"):
            print("\nChoose a level: \n[1] Basic (Guessing word)  \n[2] Intermediate (Guessing phrase)  \n[q] Quit")
            lvl = input("Your choice: ").strip().lower()
        if lvl == "q":
            break
        level = "basic" if lvl == "1" else "intermediate"
        won = play_round(level=level, lives=6)
        rounds += 1
        if won:
            score += 1

        again = input("Play another round? [y/n]: ").strip().lower()
        if again != "y":
            break

    print(f"Thanks for playing! Rounds: {rounds}, Wins: {score}")

if __name__ == "__main__":
    main()
