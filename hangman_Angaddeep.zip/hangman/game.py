
from dataclasses import dataclass, field
from typing import Set, List

@dataclass
class GameState:
    enteredletter: str
    lives: int = 6
    enteredguess: Set[str] = field(default_factory=set)
    missedguess: Set[str] = field(default_factory=set)

    @property
    def normalized_enteredletter(self) -> str:
        return self.enteredletter.lower()

    def masked(self) -> str:
        # display the dashes or enteredguess letters.
        return " ".join(
            ch if (not ch.isalpha()) or (ch.lower() in self.enteredguess) else "_"
            for ch in self.enteredletter
        )

    def is_won(self) -> bool:
        # won if all letters revealed
        for ch in self.normalized_enteredletter:
            if ch.isalpha() and ch not in self.enteredguess:
                return False
        return True

    def is_lost(self) -> bool:
        return self.lives <= 0

    def guess(self, letter: str) -> bool:
        letter = (letter or "").lower().strip()
        if len(letter) != 1 or not letter.isalpha():
            raise ValueError("Guess must be a single alphabetic character.")
        if letter in self.enteredguess or letter in self.missedguess:
            # no penalty for repeated guess
            return letter in self.enteredguess
        if letter in self.normalized_enteredletter:
            self.enteredguess.add(letter)
            return True
        else:
            self.missedguess.add(letter)
            self.lives -= 1
            return False
