
# Hangman using TDD and automated unit testing 

In this project we demonstrate the construction of simple hangman game built using TDD and automated unit testing.

## Structure
```
hangman_tdd/
  hangman/
    __init__.py
    game.py              # Core game logic (fully unit tested)
    words.py             # Word/phrase providers with validation check
    cli.py               # Console UI with 15-second timer per guess
  tests/
    test_game.py         # Unit tests using built-in unittest
  README.md
```

## To run the TDD and Automated unit tests.
```
python -m unittest discover -s tests -v
```

## How to play
```
python -m hangman.cli
```
You'll be prompted to choose a level:
- **1** = Basic (random word)
- **2** = Intermediate (random phrase)

The game enforces a **15-second timer** on each guess. If you don't enter a letter in time, you lose a life.